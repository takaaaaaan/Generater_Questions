import streamlit as st

def render():
    st.title("Code")
    line_number = st.selectbox("Display line number",["표시","가리기"])
    line_number = True if line_number == "표시" else False
    code = '''
import cv2
import streamlit as st
import numpy as np
from PIL import Image
from streamlit_webrtc import VideoTransformerBase, webrtc_streamer
import requests
import base64
import openai
from googletrans import Translator

tr = Translator()

def render():

    # 이미지의 명암 대조 조정하기
    def adjust_contrast(img, contrast=1.5):
        img = img.astype(np.float32)
        img = img * contrast
        img = np.clip(img, 0, 255)
        return img.astype(np.uint8)

    openai.api_key = "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"
    
    def generate_questions(text, num_questions, question_type, difficulty, topic, language):
        # 질문 생성 시작
        messages = []

        # 사용자로부터의 정보 설정
        if language == '한국어':
            user_message = {
                "role": "user",
                "content": f"""
                안녕하세요 ChatGPT, 저는 특정 텍스트에서 시험 문제를 만들고자 합니다. 아래 정보를 바탕으로 문제 생성을 도와주시면 좋겠습니다.
                - 언어: {language}
                - 사용할 텍스트: {text}
                - 생성하고자 하는 문제 형식: {question_type}
                - 문제 수: {num_questions}
                - 난이도: {difficulty}
                - 문제 주제: {topic}
                위의 정보를 바탕으로 최적의 문제를 만들어주시면 감사하겠습니다. 잘 부탁드립니다.
                """
            }
        elif language == '日本語':
            user_message = {
                "role": "user",
                "content": f"""
                こんにちは ChatGPT、私は特定のテキストから試験問題を作成したいと思います。以下の情報に基づいて問題の作成をお願いします。
                - 言語: {language}
                - 使用するテキスト: {text}
                - 作成したい問題形式: {question_type}
                - 問題数: {num_questions}
                - 難易度: {difficulty}
                - 問題のトピック: {topic}
                以上の情報に基づいて最適な問題を作成していただければ幸いです。よろしくお願いいたします。
                """
            }
        elif language == 'English':
            user_message = {
                "role": "user",
                "content": f"""
                Hello ChatGPT, I would like to create exam questions from a specific text. Please help me create questions based on the information below.
                - language: {language}
                - Text to use: {text}
                - Question format I want to create: {question_type}
                - Number of questions: {num_questions}
                - Difficulty: {difficulty}
                - Topic of the question: {topic}
                I would appreciate it if you could create the best questions based on the above information. Thank you.
                """
            }
        elif language == '中文':
            user_message = {
                "role": "user",
                "content": f"""
                你好，ChatGPT，我想从特定的文本中创建考试问题。请根据以下信息帮助我创建问题。
                - 语言：{language}
                - 使用的文本：{text}
                - 我想创建的问题格式：{question_type}
                - 问题数量：{num_questions}
                - 难度：{difficulty}
                - 问题的主题：{topic}
                如果您能根据以上信息创建最好的问题，我将不胜感激。谢谢您。
                """
            }
        elif language == 'မြန်မာဘာသာ':
            user_message = {
                "role": "user",
                "content": f"""
                ဟယ်လို ChatGPT၊ ကျွန်တော်က သတ်မှတ်ထားသောစာသားမှ စာစစ်မေးခွန်းများဖန်တီးလိုပါသည်။ ကျွန်တော်အတွက် အောက်ပါအချက်အလက်များအပေါ်မူတည်၍ မေးခွန်းများဖန်တီးရန် အကူအညီပေးပါ။
                - ဘာသာစကား：{language}
                - အသုံးပြုလိုသည့် စာသား：{text}
                - ဖန်တီးလိုသည့် မေးခွန်းပုံစံ：{question_type}
                - မေးခွန်းအရေအတွက်：{num_questions}
                - အခက်အခဲ：{difficulty}
                - မေးခွန်း၏ အကြောင်းအရာ：{topic}
                အထက်ပါအချက်အလက်များအပေါ်မူတည်၍ အောက်ပါအဖြေကိုဖန်တီးပေးရန်အလွန်ကျေးဇူးပြုပါသည်။ ကျေးဇူးပြု၍အဆင့်မြင့်အဖြေကိုဖန်တီးပေးပါ။
                """
            }

        messages.append(user_message)

        # OpenAI Chat model 호출
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-16k",  # 최신 모델명으로 바꿔주세요
            messages=messages,
        )

        assistant_content = response.choices[0].message["content"].strip()

        st.write(f"📝\n{assistant_content}")

    def generate_answer(text, question, answer_type, language):
        # 使用者からの情報設定
        if language == '한국어':
            user_message = {
                "role": "user",
                "content": f"""
                안녕하세요 ChatGPT, 방금 생성한 아래 문제의 답을 알려주세요.
                - 언어: {language}
                - 문제 텍스트: {question}
                - 참고 텍스트: {text}
                - 답변 형식: {answer_type}
                위의 정보를 바탕으로 최적의 해답을 만들어주시면 감사하겠습니다. 잘 부탁드립니다.
                """
            }
        elif language == '日本語':
            user_message = {
                "role": "user",
                "content": f"""
                こんにちは ChatGPT、先ほど作成した以下の問題の答えを教えてください。
                - 言語: {language}
                - 問題テキスト: {question}
                - 参考テキスト: {text}
                - 回答の形式 : {answer_type}
                以上の情報をもとに、最適な解答を作成いただければ幸いです。よろしくお願いします。
                """
            }
        elif language == 'English':
            user_message = {
                "role": "user",
                "content": f"""
                Hello ChatGPT, please tell me the answer to the question I just created.
                - language: {language}
                - Question text: {question}
                - Reference text: {text}
                - Answer format: {answer_type}
                Based on the above information, I would appreciate it if you could create the optimal answer. Thank you.
                """
            }
        elif language == '中文':
            user_message = {
                "role": "user",
                "content": f"""
                你好，ChatGPT，请告诉我刚刚创建的以下问题的答案。
                - 语言：{language}
                - 问题文本：{question}
                - 参考文本：{text}
                - 回答格式：{answer_type}
                希望您能根据以上信息，创建出最佳答案。谢谢。
                """
            }
        elif language == 'မြန်မာဘာသာ':
            user_message = {
                "role": "user",
                "content": f"""
                ဟယ်လို ChatGPT၊ ကျွန်တော်က ဖန်တီးခဲ့သောအောက်ပါမေးခွန်း၏ အဖြေကိုပေးပါ။
                - ဘာသာစကား：{language}
                - မေးခွန်းစာသား：{question}
                - ရည်ညွှန်းစာသား：{text}
                - အဖြေအစီအစဉ်：{answer_type}
                အထက်ပါအချက်အလက်များအပေါ်မူတည်၍၊ အောက်ပါအဖြေကိုဖန်တီးပေးရန်အလွန်ကျေးဇူးပြုပါသည်။ ကျေးဇူးပြု၍အဆင့်မြင့်အဖြေကိုဖန်တီးပေးပါ။
                """
            }

        # OpenAI Chat model 호출
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-16k",  # 최신 모델명으로 바꿔주세요
            messages=[user_message],
        )

        answer = response.choices[0].message["content"].strip()
        st.write(f" 💡: {answer}")

        return answer


    st.title("😊문제를 업로드해주세요~!!😊")
    with st.form(key='settings',):
        st.header('📑문제 형식을 설정')
        num_questions = st.slider('문제 수를 선택해주세요', min_value=1, max_value=10, value=5, step=1)
        question_type = st.selectbox('문제 형식을 선택하세요', options=["선택지 문제", "빈칸 채우기 문제", "간단 서술형 문제"], index=0)
        language = st.selectbox('문제 언어를 선택해주세요',options=["한국어","English","日本語","中文","မြန်မာဘာသာ"])
        col1, col2, col3 = st.columns(3)
        difficulty = col1.radio('난이도를 선택하세요', ["쉬움", "보통", "어려움", "매우 어려움"])
        topic = col2.radio('문제 주제', ["전체적인 주제", "특정 부분에 초점을 맞춤"])
        answer_type = col3.radio('답변 유형', ["다지선다", "참거짓", "간단 서술형", "서술형", "수치형"])

        submit_button = st.form_submit_button('저장')

    class VideoTransformer(VideoTransformerBase):
        def __init__(self):
            self.capture_enabled = False
            self.saved_image = None

        def transform(self, frame):
            img = frame.to_ndarray(format="bgr24")

            # 플래그가 활성화되었을 때 이미지 캡처하기
            if self.capture_enabled:
                self.saved_image = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                self.capture_enabled = False

            return img

    # 이미지 소스 선택 옵션
    option = st.selectbox('이미지 소스를 선택하세요', ('이미지 소스 선택', '📥이미지 업로드', '📸카메라로 캡처하기'))

    img = None

    if option == '📥이미지 업로드':
        uploaded_file = st.file_uploader("이미지를 선택하세요...", type="jpg")
        if uploaded_file is not None:
            img = Image.open(uploaded_file)
            img = np.array(img)

    elif option == '📸카메라로 캡처하기':
        ctx = webrtc_streamer(key="example", video_transformer_factory=VideoTransformer)

        if st.button('캡처하기'):
            st.caption('2번 눌러주세요')
            ctx.video_transformer.capture_enabled = True
            st.write('이미지가 캡처되었습니다.')

        if ctx.video_transformer and ctx.video_transformer.saved_image is not None:
            img = ctx.video_transformer.saved_image

    # 이미지가 있는 경우 OpenCV 효과 적용
    if img is not None:
        gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        contrast_img = adjust_contrast(gray_img)

        # 이미지 출력
        st.image(contrast_img, caption='처리 후 이미지', use_column_width=True)

        # 이미지 저장
        cv2.imwrite('processed_image.jpg', contrast_img)

        # 이미지 파일 읽기
        with open("processed_image.jpg", "rb") as img_file:
            my_string = base64.b64encode(img_file.read()).decode()

        # 요청 페이로드 준비
        request_payload = {
            "requests": [
                {
                    "image": {
                        "content": my_string
                    },
                    "features": [
                        {
                            "type": "TEXT_DETECTION"
                        }
                    ]
                }
            ]
        }

        response = requests.post(
            url='https://vision.googleapis.com/v1/images:annotate?key=AIzaSyDAMkNqy8UIL4xN40FbTVE5zYC0ucq8Mtw',
            json=request_payload)

        # レスポンスからテキスト抽出
        text = response.json()['responses'][0]['fullTextAnnotation']['text']
        st.title("📖원본 문장📖")
        st.write(text)
        # Language code mapping
        language_code_mapping = {
            "한국어": "ko",
            "English": "en",
            "日本語": "ja",
            "中文": "zh-CN",  # Simplified Chinese
            "မြန်မာဘာသာ": "my"  # Burmese (Myanmar)
        }

        # Get language code from mapping
        language_code = language_code_mapping.get(language)
        translated_text = tr.translate(text=text, dest=language_code).text
        st.title("📖번역 문장📖")
        st.text(translated_text)
        
    # Google Cloud Vision에서 얻은 텍스트 사용
    if option == '📥이미지 업로드' or option == '📸카메라로 캡처하기':
        with st.form(key='question_creation'):
            # "문제 생성" 버튼
            submit_button = st.form_submit_button('✅문제 생성')
            # Usage
            if submit_button:
                generate_questions(text, num_questions, question_type, difficulty, topic,language)
                generate_answer(text, num_questions, answer_type,language)
        '''
    st.code(code,language = 'python',line_numbers=line_number)