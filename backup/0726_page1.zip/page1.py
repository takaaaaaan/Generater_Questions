import cv2
import streamlit as st
import numpy as np
from PIL import Image
from streamlit_webrtc import VideoTransformerBase, webrtc_streamer
import requests
import base64
import openai
import pickle


def render():

    # 이미지의 명암 대조 조정하기
    def adjust_contrast(img, contrast=1.5):
        img = img.astype(np.float32)
        img = img * contrast
        img = np.clip(img, 0, 255)
        return img.astype(np.uint8)

    openai.api_key = "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"

    def generate_questions(text, num_questions, question_type, difficulty, topic):
        # 問題生成を開始
        messages = []

            # ユーザーからの情報を設定
        user_message = {
                "role": "user",
                "content": f"""
                こんにちはChatGPT、私はあるテキストから試験問題を作成したいと思っています。以下の情報をもとに、問題作成をお手伝いいただけますか？
                - 使用したいテキスト: {text}
                - 作成したい問題の形式: {question_type}
                - 問題数: {num_questions}
                - 難易度: {difficulty}
                - 問題のトピック: {topic}
                以上の情報をもとに、最適な問題を作成いただければ幸いです。よろしくお願いします。
                """
            }
        messages.append(user_message)

        # OpenAI Chat modelの呼び出し
        response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo-16k",  # 最新のモデル名に置き換えてください
                messages=messages,
            )

        assistant_content = response.choices[0].message["content"].strip()

        st.write(f"###{assistant_content}")

    def generate_answer(text, question,answer_type):
        # ユーザーからの情報を設定
        user_message = {
            "role": "user",
            "content": f"""
            こんにちはChatGPT、先ほど作成した以下の問題の答えを教えてください。
            - 問題テキスト: {question}
            - 参考テキスト: {text}
            - {answer_type}
            以上の情報をもとに、最適な解答を作成いただければ幸いです。よろしくお願いします。
            """
        }

        # OpenAI Chat modelの呼び出し
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo-16k",  # 最新のモデル名に置き換えてください
            messages=[user_message],
        )

        answer = response.choices[0].message["content"].strip()
        st.write(f" : {answer}")

        return answer

    st.title("😊문제를 업로드해주세요~!!😊")
    with st.form(key='settings',):
        st.header('문제 형식을 설정')
        
        num_questions = st.slider('問題数を入力してください', min_value=1, max_value=10, value=5, step=1)
        question_type = st.selectbox('問題形式を選択してください', options=["選択肢式", "穴埋め問題", "短答式"], index=0)
        difficulty= st.radio('難易度を選択してください',["簡単","中程度","難しい","激むず"])
        topic = st.radio('問題のトピック',["全体的な主題","特定の部分に焦点を当てる"])
        answer_type = st.radio('답변 유형',["","",""])
        
        submit_button = st.form_submit_button('保存')

    
    class VideoTransformer(VideoTransformerBase):
        def __init__(self):
            self.capture_enabled = False
            self.saved_image = None

        def transform(self, frame):
            img = frame.to_ndarray(format="bgr24")

            # 플래그가 활성화되었을 때 이미지 캡처하기
            if self.capture_enabled:
                self.saved_image = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                self.capture_enabled = False

            return img


    # 이미지 소스 선택 옵션
    option = st.selectbox('이미지 소스를 선택하세요', ('이미지 소스 선택', '이미지 업로드', '카메라로 캡처하기'))

    img = None

    if option == '이미지 업로드':
        uploaded_file = st.file_uploader("이미지를 선택하세요...", type="jpg")
        if uploaded_file is not None:
            img = Image.open(uploaded_file)
            img = np.array(img)

    elif option == '카메라로 캡처하기':
        ctx = webrtc_streamer(key="example", video_transformer_factory=VideoTransformer)

        if st.button('캡처하기'):
            st.caption('2번 눌어주세요')
            ctx.video_transformer.capture_enabled = True
            st.write('이미지가 캡처되었습니다.')

        if ctx.video_transformer and ctx.video_transformer.saved_image is not None:
            img = ctx.video_transformer.saved_image

    # 이미지가 있는 경우 OpenCV 효과 적용
    if img is not None:
        gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        contrast_img = adjust_contrast(gray_img)

        # 이미지 출력
        st.image(contrast_img, caption='처리 후 이미지', use_column_width=True)

        # 이미지 저장
        cv2.imwrite('processed_image.jpg', contrast_img)

        # 이미지 파일 읽기
        with open("processed_image.jpg", "rb") as img_file:
            my_string = base64.b64encode(img_file.read()).decode()

        # 요청 페이로드 준비
        request_payload = {
            "requests": [
                {
                    "image": {
                        "content": my_string
                    },
                    "features": [
                        {
                            "type": "TEXT_DETECTION"
                        }
                    ]
                }
            ]
        }

        response = requests.post(
            url='https://vision.googleapis.com/v1/images:annotate?key=AIzaSyDAMkNqy8UIL4xN40FbTVE5zYC0ucq8Mtw',
            json=request_payload)

        # 응답에서 텍스트 추출
        text = response.json()['responses'][0]['fullTextAnnotation']['text']
        st.title("📖원본 문장📖")
        st.write(text)

    # Google Cloud Vision에서 얻은 텍스트 사용
    if option == '이미지 업로드' or option == '카메라로 캡처하기':
        with st.form(key='question_creation'):
            # "문제 생성" ボタン
            submit_button = st.form_submit_button('문제 생성')
            # Usage
            if submit_button:
                # Google Cloud Vision에서 얻은 텍스트 사용
                if text is not None:
                    user_content = text
                else:
                    user_content = "기본 텍스트"  # 또는 원하는 내용으로 대체

                generate_questions(text, num_questions, question_type, difficulty, topic)
                generate_answer(text, num_questions, answer_type)
