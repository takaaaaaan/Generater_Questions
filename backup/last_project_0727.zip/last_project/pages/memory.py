import streamlit as st
import pickle

st.write("Memory")

