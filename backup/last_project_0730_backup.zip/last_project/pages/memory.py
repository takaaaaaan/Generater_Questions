import streamlit as st
import pickle
import os

# データを読み込むための関数
def load_data(file_path):
    if os.path.exists(file_path):
        if os.path.getsize(file_path) > 0:
            with open(file_path, "rb") as f:
                data = pickle.load(f)
                if isinstance(data, list):  # ここを修正します
                    return data
                else:
                    st.write("Error: The content of the file is not a list.")
        else:
            st.write("Error: The file is empty.")
    else:
        st.write(f"Error: The file does not exist. Please check if \'{file_path}\' exists.")
    return None

if __name__ == "__main__":
    st.title("Past Questions and Answers")
    history_file_path = './inputs/history.pkl'
    data = load_data(history_file_path)

    # データが存在する場合は変数に格納
    if data is not None:
        # Streamlitでデータを表示
        for i, entry in enumerate(data):
            st.subheader(f"Entry {i+1}")
            st.write("Question:", entry.get('new_question'))
            st.write("Answer:", entry.get('new_answer'))
            st.write("Text:", entry.get('new_text'))
            st.write("Translated Text:", entry.get('new_text_language'))

    # Streamlitアプリにボタンを作成
    if st.button('Clear File'):
        # クリアするファイルを指定
        filename = history_file_path

        # ファイルが存在するか確認
        if os.path.exists(filename):
            # ファイルを開いて内容をクリア
            with open(filename, 'wb') as f:
                pickle.dump([], f)
            st.write(f"{filename} has been cleared.")
        else:
            st.write("The file does not exist.")
