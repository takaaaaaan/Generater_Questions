# page2.py

import streamlit as st

def render():
    
    # st.stop()
    st.echo()
    with st.echo():
        st.write('Code will be executed and printed')
    st.title('Display text')
    st.text('Fixed width text')
    st.markdown('_Markdown_') # see *
    st.caption('Balloons. Hundreds of them...')
    st.latex(r''' e^{i\pi} + 1 = 0 ''')
    st.write('Most objects') # df, err, func, keras!
    st.write(['st', 'is <', 3]) # see *
    st.title('My title')
    st.header('My header')
    st.subheader('My sub')
    st.code('for i in range(8): foo()')
#########################################################
    st.title('Display interactive widgets')
    st.button('Hit me')
    
    a = st.sidebar.radio('R:',[1,2])
    # ダウンロード対象のデータを設定（テキスト例）
    text_data = "Hello, this is the downloadable text."

    # ダウンロードボタンを作成（テキスト例）
    st.download_button('Download Text', text_data, file_name='downloaded_text.txt')

    st.checkbox('Check me out')
    st.radio('Radio', [1, 2, 3])
    st.selectbox('Select', [1, 2, 3])
    st.multiselect('Multiselect', [1, 2, 3])
    st.slider('Slide me', min_value=0, max_value=10)
    st.select_slider('Slide to select', options=[1, '2'])
    st.text_input('Enter some text')
    st.number_input('Enter a number')
    st.text_area('Area for textual entry')
    st.date_input('Date input')
    st.time_input('Time entry')
    st.file_uploader('File uploader')
    st.camera_input("一二三,茄子!")
    st.color_picker('Pick a color')
    st.title("Magpasa ng papel pang obserba ng sintomas")
    st.write('1. Piliin ang araw NA NAKASULAT SA PAPEL ng pasyente.')
    date = st.date_input('Araw ng pag record')
    st.write('2. Iclick ang allow sa pag gamit ng camera at picturan ang buong papel o mag upload ng larawan ng papel.')
    st.write('3. Intayin ang kumpirmasyon na naupload ang resulta')
    st.title("")
    st.title("")