import streamlit as st
import pickle
import os
import json

def load_data_pickle(file_path):
    if os.path.exists(file_path):
        if os.path.getsize(file_path) > 0:
            with open(file_path, "rb") as f:
                data = pickle.load(f)
                if isinstance(data, dict):  
                    return data
                else:
                    st.write("エラー：ファイルの内容が辞書ではありません。")
        else:
            st.write("エラー：ファイルが空です。")
    else:
        st.write(f"エラー：ファイルが存在しません。\'{file_path}\'が存在するか確認してください。")
    return None

def load_data_json(file_path):
    if os.path.exists(file_path):
        if os.path.getsize(file_path) > 0:
            with open(file_path, "r") as f:
                data = json.load(f)
                if isinstance(data, dict):  
                    return data
                else:
                    st.write("エラー：ファイルの内容が辞書ではありません。")
        else:
            st.write("エラー：ファイルが空です。")
    else:
        st.write(f"エラー：ファイルが存在しません。\'{file_path}\'が存在するか確認してください。")
    return None

if __name__ == "__main__":
    st.title("過去の質問と回答")
    history_file_path_pickle = './inputs/history.pkl'
    history_file_path_json = './inputs/history.json'
    data_pickle = load_data_pickle(history_file_path_pickle)
    data_json = load_data_json(history_file_path_json)

    # データが存在する場合は変数に格納
    if data_pickle is not None:
        # Streamlitでデータを表示
        for i, entry in enumerate(data_pickle):
            st.subheader(f"エントリー {i+1} (pickle)")
            st.write("質問：", entry.get('new_question'))
            st.write("回答：", entry.get('new_answer'))
            st.write("テキスト：", entry.get('new_text'))
            st.write("翻訳テキスト：", entry.get('new_text_language'))

    if data_json is not None:
        # Streamlitでデータを表示
        for i, entry in enumerate(data_json):
            st.subheader(f"エントリー {i+1} (json)")
            st.write("質問：", entry.get('new_question'))
            st.write("回答：", entry.get('new_answer'))
            st.write("テキスト：", entry.get('new_text'))
            st.write("翻訳テキスト：", entry.get('new_text_language'))

    # Streamlitアプリにボタンを作成
    if st.button('ファイルをクリア'):
        # クリアするファイルを指定
        filename = history_file_path_pickle

        # ファイルが存在するか確認
        if os.path.exists(filename):
            # ファイルを開いて内容をクリア
            with open(filename, 'wb') as f:
                pickle.dump({}, f)
            st.write(f"{filename}をクリアしました。")
        else:
            st.write("ファイルが存在しません。")

